import { Button } from "@/components/ui/button"
import Link from "next/link"

export function TemplatesSection() {
  const templates = [
    {
      id: "professional",
      name: "Professional",
      description: "Clean and modern design for corporate environments",
      color: "bg-blue-50",
      accent: "border-blue-500",
    },
    {
      id: "creative",
      name: "Creative",
      description: "Unique layout for design and creative industries",
      color: "bg-purple-50",
      accent: "border-purple-500",
    },
    {
      id: "executive",
      name: "Executive",
      description: "Sophisticated template for senior positions",
      color: "bg-gray-50",
      accent: "border-gray-700",
    },
    {
      id: "simple",
      name: "Simple",
      description: "Minimalist design focusing on content",
      color: "bg-emerald-50",
      accent: "border-emerald-500",
    },
    {
      id: "modern",
      name: "Modern",
      description: "Contemporary design with a clean layout",
      color: "bg-cyan-50",
      accent: "border-cyan-500",
    },
    {
      id: "elegant",
      name: "Elegant",
      description: "Refined design with a touch of sophistication",
      color: "bg-amber-50",
      accent: "border-amber-500",
    },
  ]

  return (
    <section className="py-20">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Choose from 200+ templates</h2>
            <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Find the perfect template that matches your style and industry requirements
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-6xl grid-cols-1 gap-8 py-12 md:grid-cols-2 lg:grid-cols-3">
          {templates.map((template) => (
            <div
              key={template.id}
              className="group relative flex flex-col items-center space-y-2 rounded-lg border bg-white p-4 shadow-sm transition-all hover:shadow-md"
            >
              <div
                className={`relative h-[350px] w-full overflow-hidden rounded-md border-2 ${template.accent} ${template.color}`}
              >
                <div className="absolute inset-0 p-6">
                  <div className="h-12 w-3/4 bg-gray-800 rounded mb-4"></div>
                  <div className="h-4 w-1/2 bg-gray-600 rounded mb-6"></div>
                  <div className="space-y-2">
                    <div className="h-3 bg-gray-600 rounded w-full"></div>
                    <div className="h-3 bg-gray-600 rounded w-full"></div>
                    <div className="h-3 bg-gray-600 rounded w-5/6"></div>
                  </div>
                  <div className="mt-6 pt-6 border-t border-gray-300">
                    <div className="h-4 w-1/3 bg-gray-800 rounded mb-3"></div>
                    <div className="space-y-2">
                      <div className="h-3 bg-gray-600 rounded w-full"></div>
                      <div className="h-3 bg-gray-600 rounded w-full"></div>
                    </div>
                  </div>
                  <div className="mt-6 pt-6 border-t border-gray-300">
                    <div className="h-4 w-1/3 bg-gray-800 rounded mb-3"></div>
                    <div className="flex flex-wrap gap-2">
                      <div className="h-6 w-16 bg-gray-600 rounded-full"></div>
                      <div className="h-6 w-20 bg-gray-600 rounded-full"></div>
                      <div className="h-6 w-14 bg-gray-600 rounded-full"></div>
                    </div>
                  </div>
                </div>
                <div className="absolute bottom-3 right-3 bg-white px-3 py-1 rounded-full text-sm font-medium shadow-sm">
                  {template.name}
                </div>
              </div>
              <h3 className="text-xl font-bold">{template.name}</h3>
              <p className="text-center text-sm text-gray-500">{template.description}</p>
              <Link href={`/builder?template=${template.id}`} className="mt-auto w-full">
                <Button variant="outline" className="w-full">
                  Use this template
                </Button>
              </Link>
            </div>
          ))}
        </div>
        <div className="flex justify-center">
          <Link href="/builder">
            <Button variant="outline" className="mt-4">
              View all templates
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
