"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PersonalInfoForm } from "@/components/personal-info-form"
import { ExperienceForm } from "@/components/experience-form"
import { EducationForm } from "@/components/education-form"
import { SkillsForm } from "@/components/skills-form"
import { ResumePreview } from "@/components/resume-preview"
import { TemplateSelector } from "@/components/template-selector"
import { AiAssistant } from "@/components/ai-assistant"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { useToast } from "@/hooks/use-toast"
import type { ResumeData } from "@/types/resume"

interface ResumeBuilderProps {
  initialTemplate?: string | null
}

export function ResumeBuilder({ initialTemplate = null }: ResumeBuilderProps) {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("personal")
  const [selectedTemplate, setSelectedTemplate] = useState(initialTemplate || "professional")
  const [resumeData, setResumeData] = useState<ResumeData>({
    personal: {
      name: "",
      email: "",
      phone: "",
      address: "",
      title: "",
      summary: "",
    },
    experience: [],
    education: [],
    skills: [],
  })
  const [showAiAssistant, setShowAiAssistant] = useState(false)

  const updateResumeData = (section: string, data: any) => {
    setResumeData((prev) => ({
      ...prev,
      [section]: data,
    }))
  }

  const handleNext = () => {
    const tabs = ["personal", "experience", "education", "skills", "template"]
    const currentIndex = tabs.indexOf(activeTab)
    if (currentIndex < tabs.length - 1) {
      setActiveTab(tabs[currentIndex + 1])
    }
  }

  const handlePrevious = () => {
    const tabs = ["personal", "experience", "education", "skills", "template"]
    const currentIndex = tabs.indexOf(activeTab)
    if (currentIndex > 0) {
      setActiveTab(tabs[currentIndex - 1])
    }
  }

  const handleSave = () => {
    toast({
      title: "Resume saved",
      description: "Your resume has been saved successfully.",
    })
  }

  const handleDownload = () => {
    // In a real app, this would generate and download a PDF
    toast({
      title: "PDF Generated",
      description: "Your resume has been generated as a PDF and is ready to download.",
    })

    // Simulate download delay
    setTimeout(() => {
      toast({
        title: "Resume downloaded",
        description: "Your resume has been downloaded as a PDF.",
      })
    }, 1000)
  }

  return (
    <>
      <Navbar />
      <div className="container py-8">
        <div className="mb-8 flex items-center justify-between">
          <h1 className="text-3xl font-bold">Build Your Resume</h1>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => setShowAiAssistant(!showAiAssistant)}>
              {showAiAssistant ? "Hide AI Assistant" : "Show AI Assistant"}
            </Button>
            <Button variant="outline" onClick={handleSave}>
              Save
            </Button>
            <Button onClick={handleDownload}>Download PDF</Button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_400px]">
          <div>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-8 grid w-full grid-cols-5">
                <TabsTrigger value="personal">Personal</TabsTrigger>
                <TabsTrigger value="experience">Experience</TabsTrigger>
                <TabsTrigger value="education">Education</TabsTrigger>
                <TabsTrigger value="skills">Skills</TabsTrigger>
                <TabsTrigger value="template">Template</TabsTrigger>
              </TabsList>
              <TabsContent value="personal">
                <PersonalInfoForm
                  data={resumeData.personal}
                  updateData={(data) => updateResumeData("personal", data)}
                />
              </TabsContent>
              <TabsContent value="experience">
                <ExperienceForm
                  data={resumeData.experience}
                  updateData={(data) => updateResumeData("experience", data)}
                />
              </TabsContent>
              <TabsContent value="education">
                <EducationForm data={resumeData.education} updateData={(data) => updateResumeData("education", data)} />
              </TabsContent>
              <TabsContent value="skills">
                <SkillsForm data={resumeData.skills} updateData={(data) => updateResumeData("skills", data)} />
              </TabsContent>
              <TabsContent value="template">
                <TemplateSelector selectedTemplate={selectedTemplate} setSelectedTemplate={setSelectedTemplate} />
              </TabsContent>
            </Tabs>

            <div className="mt-8 flex justify-between">
              <Button variant="outline" onClick={handlePrevious} disabled={activeTab === "personal"}>
                Previous
              </Button>
              <Button onClick={handleNext} disabled={activeTab === "template"}>
                Next
              </Button>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <ResumePreview data={resumeData} template={selectedTemplate} />
            {showAiAssistant && <AiAssistant resumeData={resumeData} updateResumeData={updateResumeData} />}
          </div>
        </div>
      </div>
      <Footer />
    </>
  )
}
