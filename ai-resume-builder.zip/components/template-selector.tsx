"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface TemplateSelectorProps {
  selectedTemplate: string
  setSelectedTemplate: (template: string) => void
}

export function TemplateSelector({ selectedTemplate, setSelectedTemplate }: TemplateSelectorProps) {
  const templates = [
    {
      id: "professional",
      name: "Professional",
      description: "Clean and modern design for corporate environments",
      color: "bg-blue-50",
      accent: "border-blue-500",
    },
    {
      id: "creative",
      name: "Creative",
      description: "Unique layout for design and creative industries",
      color: "bg-purple-50",
      accent: "border-purple-500",
    },
    {
      id: "executive",
      name: "Executive",
      description: "Sophisticated template for senior positions",
      color: "bg-gray-50",
      accent: "border-gray-700",
    },
    {
      id: "simple",
      name: "Simple",
      description: "Minimalist design focusing on content",
      color: "bg-emerald-50",
      accent: "border-emerald-500",
    },
    {
      id: "modern",
      name: "Modern",
      description: "Contemporary design with a clean layout",
      color: "bg-cyan-50",
      accent: "border-cyan-500",
    },
    {
      id: "elegant",
      name: "Elegant",
      description: "Refined design with a touch of sophistication",
      color: "bg-amber-50",
      accent: "border-amber-500",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Choose a Template</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {templates.map((template) => (
            <div
              key={template.id}
              className={`cursor-pointer rounded-lg border p-4 transition-all hover:shadow-md ${
                selectedTemplate === template.id ? "ring-2 ring-emerald-500" : ""
              }`}
              onClick={() => setSelectedTemplate(template.id)}
            >
              <div
                className={`relative mx-auto mb-4 h-[200px] w-[150px] overflow-hidden rounded border-2 ${template.accent} ${template.color}`}
              >
                <div className="absolute inset-0 p-4">
                  <div className="h-8 w-3/4 bg-gray-800 rounded mb-3"></div>
                  <div className="h-3 w-1/2 bg-gray-600 rounded mb-4"></div>
                  <div className="space-y-1">
                    <div className="h-2 bg-gray-600 rounded w-full"></div>
                    <div className="h-2 bg-gray-600 rounded w-full"></div>
                    <div className="h-2 bg-gray-600 rounded w-5/6"></div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-300">
                    <div className="h-3 w-1/3 bg-gray-800 rounded mb-2"></div>
                    <div className="space-y-1">
                      <div className="h-2 bg-gray-600 rounded w-full"></div>
                      <div className="h-2 bg-gray-600 rounded w-full"></div>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-300">
                    <div className="h-3 w-1/3 bg-gray-800 rounded mb-2"></div>
                    <div className="flex flex-wrap gap-1">
                      <div className="h-4 w-10 bg-gray-600 rounded-full"></div>
                      <div className="h-4 w-14 bg-gray-600 rounded-full"></div>
                      <div className="h-4 w-8 bg-gray-600 rounded-full"></div>
                    </div>
                  </div>
                </div>
              </div>
              <h3 className="text-center text-lg font-medium">{template.name}</h3>
              <p className="text-center text-sm text-gray-500">{template.description}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
