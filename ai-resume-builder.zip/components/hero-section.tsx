import Link from "next/link"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export function HeroSection() {
  return (
    <section className="py-20 md:py-28">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_600px] lg:gap-12 xl:grid-cols-[1fr_650px]">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Take your resume from good to <span className="text-emerald-600">great</span> in just{" "}
                <span className="text-emerald-600">minutes</span>
              </h1>
              <p className="max-w-[600px] text-gray-500 md:text-xl">
                Create the perfect ATS-friendly resume with a smart AI builder and 200+ template variations
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/builder">
                <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
                  Create new resume
                </Button>
              </Link>
              <Link href="/improve">
                <Button size="lg" variant="outline">
                  Improve my resume
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative h-[500px] w-full overflow-hidden rounded-xl border bg-white shadow-xl">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="Resume preview"
                width={600}
                height={500}
                className="object-cover"
                priority
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
