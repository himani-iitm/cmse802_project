import type { ResumeData } from "@/types/resume"

interface CreativeTemplateProps {
  data: ResumeData
}

export function CreativeTemplate({ data }: CreativeTemplateProps) {
  const { personal, experience, education, skills } = data

  return (
    <div className="font-sans">
      {/* Header with accent color */}
      <div className="bg-emerald-600 text-white p-6 rounded-t-lg">
        <h1 className="text-2xl font-bold">{personal.name || "Your Name"}</h1>
        <p className="text-emerald-100 mt-1">{personal.title || "Professional Title"}</p>
        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-3 text-sm text-emerald-50">
          {personal.email && <p>{personal.email}</p>}
          {personal.phone && <p>{personal.phone}</p>}
          {personal.address && <p>{personal.address}</p>}
        </div>
      </div>

      <div className="p-6">
        {/* Summary */}
        {personal.summary && (
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-emerald-700 mb-2">About Me</h2>
            <p className="text-gray-700">{personal.summary}</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            {/* Experience */}
            {experience.length > 0 && (
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-emerald-700 mb-3">Experience</h2>
                <div className="space-y-4">
                  {experience.map((job, index) => (
                    <div key={index} className="relative pl-6 border-l-2 border-emerald-200 pb-4">
                      <div className="absolute w-3 h-3 bg-emerald-500 rounded-full -left-[7px] top-1"></div>
                      <h3 className="font-bold text-gray-800">{job.position}</h3>
                      <p className="text-emerald-600 font-medium">{job.company}</p>
                      <p className="text-sm text-gray-500">
                        {job.startDate} - {job.endDate} | {job.location}
                      </p>
                      {job.description && <p className="text-gray-700 mt-2">{job.description}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Education */}
            {education.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold text-emerald-700 mb-3">Education</h2>
                <div className="space-y-4">
                  {education.map((edu, index) => (
                    <div key={index} className="relative pl-6 border-l-2 border-emerald-200 pb-4">
                      <div className="absolute w-3 h-3 bg-emerald-500 rounded-full -left-[7px] top-1"></div>
                      <h3 className="font-bold text-gray-800">
                        {edu.degree} {edu.field && `in ${edu.field}`}
                      </h3>
                      <p className="text-emerald-600 font-medium">{edu.institution}</p>
                      <p className="text-sm text-gray-500">
                        {edu.startDate} - {edu.endDate} | {edu.location}
                      </p>
                      {edu.description && <p className="text-gray-700 mt-2">{edu.description}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div>
            {/* Skills */}
            {skills.length > 0 && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h2 className="text-lg font-semibold text-emerald-700 mb-3">Skills</h2>
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill, index) => (
                    <span key={index} className="bg-emerald-100 text-emerald-800 text-xs px-3 py-1 rounded-full">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
