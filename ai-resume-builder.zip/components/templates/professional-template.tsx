import type { ResumeData } from "@/types/resume"

interface ProfessionalTemplateProps {
  data: ResumeData
}

export function ProfessionalTemplate({ data }: ProfessionalTemplateProps) {
  const { personal, experience, education, skills } = data

  return (
    <div className="font-sans text-gray-800">
      {/* Header */}
      <div className="border-b border-gray-300 pb-4">
        <h1 className="text-2xl font-bold text-center text-gray-900">{personal.name || "Your Name"}</h1>
        <p className="text-center text-gray-600 mt-1">{personal.title || "Professional Title"}</p>
        <div className="flex justify-center flex-wrap gap-x-4 gap-y-1 mt-2 text-sm">
          {personal.email && <p>{personal.email}</p>}
          {personal.phone && <p>{personal.phone}</p>}
          {personal.address && <p>{personal.address}</p>}
        </div>
      </div>

      {/* Summary */}
      {personal.summary && (
        <div className="mt-4">
          <h2 className="text-lg font-semibold border-b border-gray-300 pb-1 mb-2">Professional Summary</h2>
          <p className="text-sm">{personal.summary}</p>
        </div>
      )}

      {/* Experience */}
      {experience.length > 0 && (
        <div className="mt-4">
          <h2 className="text-lg font-semibold border-b border-gray-300 pb-1 mb-2">Work Experience</h2>
          <div className="space-y-3">
            {experience.map((job, index) => (
              <div key={index}>
                <div className="flex justify-between items-baseline">
                  <h3 className="font-medium">{job.position}</h3>
                  <p className="text-sm text-gray-600">
                    {job.startDate} - {job.endDate}
                  </p>
                </div>
                <p className="text-sm">
                  {job.company}
                  {job.location && `, ${job.location}`}
                </p>
                {job.description && <p className="text-sm mt-1">{job.description}</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {education.length > 0 && (
        <div className="mt-4">
          <h2 className="text-lg font-semibold border-b border-gray-300 pb-1 mb-2">Education</h2>
          <div className="space-y-3">
            {education.map((edu, index) => (
              <div key={index}>
                <div className="flex justify-between items-baseline">
                  <h3 className="font-medium">
                    {edu.degree}
                    {edu.field && ` in ${edu.field}`}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {edu.startDate} - {edu.endDate}
                  </p>
                </div>
                <p className="text-sm">
                  {edu.institution}
                  {edu.location && `, ${edu.location}`}
                </p>
                {edu.description && <p className="text-sm mt-1">{edu.description}</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {skills.length > 0 && (
        <div className="mt-4">
          <h2 className="text-lg font-semibold border-b border-gray-300 pb-1 mb-2">Skills</h2>
          <div className="flex flex-wrap gap-2">
            {skills.map((skill, index) => (
              <span key={index} className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">
                {skill}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
