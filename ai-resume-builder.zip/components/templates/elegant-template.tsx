import type { ResumeData } from "@/types/resume"

interface ElegantTemplateProps {
  data: ResumeData
}

export function ElegantTemplate({ data }: ElegantTemplateProps) {
  const { personal, experience, education, skills } = data

  return (
    <div className="font-serif text-gray-800">
      {/* Header */}
      <div className="text-center border-b-2 border-amber-300 pb-6">
        <h1 className="text-3xl font-bold">{personal.name || "Your Name"}</h1>
        <p className="text-lg text-amber-700 mt-1">{personal.title || "Professional Title"}</p>
        <div className="flex justify-center flex-wrap gap-x-6 gap-y-1 mt-3 text-sm">
          {personal.email && <p>{personal.email}</p>}
          {personal.phone && <p>{personal.phone}</p>}
          {personal.address && <p>{personal.address}</p>}
        </div>
      </div>

      <div className="py-6">
        {/* Summary */}
        {personal.summary && (
          <div className="mb-6">
            <h2 className="text-xl font-bold text-amber-700 mb-3 text-center">About Me</h2>
            <p className="text-center max-w-2xl mx-auto">{personal.summary}</p>
          </div>
        )}

        {/* Experience */}
        {experience.length > 0 && (
          <div className="mb-6">
            <h2 className="text-xl font-bold text-amber-700 mb-4 text-center">Professional Experience</h2>
            <div className="space-y-6">
              {experience.map((job, index) => (
                <div key={index} className="border-l-2 border-amber-200 pl-4">
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-gray-800">{job.position}</h3>
                    <p className="text-sm text-gray-600 italic">
                      {job.startDate} - {job.endDate}
                    </p>
                  </div>
                  <p className="text-amber-700">{job.company}</p>
                  {job.location && <p className="text-sm text-gray-600">{job.location}</p>}
                  {job.description && <p className="mt-2">{job.description}</p>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education */}
        {education.length > 0 && (
          <div className="mb-6">
            <h2 className="text-xl font-bold text-amber-700 mb-4 text-center">Education</h2>
            <div className="space-y-4">
              {education.map((edu, index) => (
                <div key={index} className="text-center">
                  <h3 className="font-bold text-gray-800">
                    {edu.degree}
                    {edu.field && ` in ${edu.field}`}
                  </h3>
                  <p className="text-amber-700">{edu.institution}</p>
                  <p className="text-sm text-gray-600">
                    {edu.startDate} - {edu.endDate}
                  </p>
                  {edu.location && <p className="text-sm text-gray-600">{edu.location}</p>}
                  {edu.description && <p className="text-sm mt-1 max-w-2xl mx-auto">{edu.description}</p>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Skills */}
        {skills.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-amber-700 mb-4 text-center">Skills</h2>
            <div className="flex flex-wrap justify-center gap-2">
              {skills.map((skill, index) => (
                <span key={index} className="bg-amber-50 text-amber-800 px-3 py-1 rounded-full border border-amber-200">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
