import type { ResumeData } from "@/types/resume"

interface ModernTemplateProps {
  data: ResumeData
}

export function ModernTemplate({ data }: ModernTemplateProps) {
  const { personal, experience, education, skills } = data

  return (
    <div className="font-sans text-gray-800">
      {/* Header with accent color */}
      <div className="bg-cyan-600 text-white p-6 rounded-t-lg">
        <h1 className="text-2xl font-bold">{personal.name || "Your Name"}</h1>
        <p className="text-cyan-100 mt-1">{personal.title || "Professional Title"}</p>
        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-3 text-sm text-cyan-50">
          {personal.email && <p>{personal.email}</p>}
          {personal.phone && <p>{personal.phone}</p>}
          {personal.address && <p>{personal.address}</p>}
        </div>
      </div>

      <div className="p-6">
        {/* Two column layout */}
        <div className="grid grid-cols-3 gap-6">
          {/* Left column */}
          <div className="col-span-1">
            {/* Skills */}
            {skills.length > 0 && (
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-cyan-700 mb-3 border-b border-cyan-200 pb-1">Skills</h2>
                <div className="space-y-2">
                  {skills.map((skill, index) => (
                    <div key={index} className="flex items-center">
                      <div className="w-2 h-2 bg-cyan-500 rounded-full mr-2"></div>
                      <span>{skill}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Education */}
            {education.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold text-cyan-700 mb-3 border-b border-cyan-200 pb-1">Education</h2>
                <div className="space-y-4">
                  {education.map((edu, index) => (
                    <div key={index}>
                      <h3 className="font-bold text-gray-800">
                        {edu.degree}
                        {edu.field && ` in ${edu.field}`}
                      </h3>
                      <p className="text-cyan-600">{edu.institution}</p>
                      <p className="text-sm text-gray-600">
                        {edu.startDate} - {edu.endDate}
                      </p>
                      {edu.location && <p className="text-sm text-gray-600">{edu.location}</p>}
                      {edu.description && <p className="text-sm mt-1">{edu.description}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right column */}
          <div className="col-span-2">
            {/* Summary */}
            {personal.summary && (
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-cyan-700 mb-3 border-b border-cyan-200 pb-1">Profile</h2>
                <p>{personal.summary}</p>
              </div>
            )}

            {/* Experience */}
            {experience.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold text-cyan-700 mb-3 border-b border-cyan-200 pb-1">Experience</h2>
                <div className="space-y-6">
                  {experience.map((job, index) => (
                    <div key={index}>
                      <div className="flex justify-between items-baseline">
                        <h3 className="font-bold text-gray-800">{job.position}</h3>
                        <p className="text-sm text-gray-600">
                          {job.startDate} - {job.endDate}
                        </p>
                      </div>
                      <p className="text-cyan-600">{job.company}</p>
                      {job.location && <p className="text-sm text-gray-600">{job.location}</p>}
                      {job.description && <p className="mt-2">{job.description}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
