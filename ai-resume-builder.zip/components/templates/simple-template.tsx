import type { ResumeData } from "@/types/resume"

interface SimpleTemplateProps {
  data: ResumeData
}

export function SimpleTemplate({ data }: SimpleTemplateProps) {
  const { personal, experience, education, skills } = data

  return (
    <div className="font-sans text-gray-800 max-w-2xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{personal.name || "Your Name"}</h1>
        <p className="text-gray-600">{personal.title || "Professional Title"}</p>
        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-sm">
          {personal.email && <p>{personal.email}</p>}
          {personal.phone && <p>{personal.phone}</p>}
          {personal.address && <p>{personal.address}</p>}
        </div>
      </div>

      {/* Summary */}
      {personal.summary && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-2 uppercase">Summary</h2>
          <p>{personal.summary}</p>
        </div>
      )}

      {/* Experience */}
      {experience.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-2 uppercase">Experience</h2>
          <div className="space-y-4">
            {experience.map((job, index) => (
              <div key={index}>
                <div className="flex justify-between">
                  <h3 className="font-bold">{job.position}</h3>
                  <p className="text-sm">
                    {job.startDate} - {job.endDate}
                  </p>
                </div>
                <p className="text-sm">
                  {job.company}
                  {job.location && `, ${job.location}`}
                </p>
                {job.description && <p className="mt-1">{job.description}</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {education.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-2 uppercase">Education</h2>
          <div className="space-y-4">
            {education.map((edu, index) => (
              <div key={index}>
                <div className="flex justify-between">
                  <h3 className="font-bold">
                    {edu.degree}
                    {edu.field && ` in ${edu.field}`}
                  </h3>
                  <p className="text-sm">
                    {edu.startDate} - {edu.endDate}
                  </p>
                </div>
                <p className="text-sm">
                  {edu.institution}
                  {edu.location && `, ${edu.location}`}
                </p>
                {edu.description && <p className="mt-1">{edu.description}</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {skills.length > 0 && (
        <div>
          <h2 className="text-lg font-bold mb-2 uppercase">Skills</h2>
          <p>{skills.join(", ")}</p>
        </div>
      )}
    </div>
  )
}
